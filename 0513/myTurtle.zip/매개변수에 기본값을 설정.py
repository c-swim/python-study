#매개변수에 기본값을 설정
hap3 = lambda num1 =10, num2= 20: num1 + num2
print(hap3())
print(hap3(100,200))