#람다 함수
def hap(num1, num2):
    res = num1 + num2
    return res
print(hap(10,20))