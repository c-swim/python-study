#삼항연산자를 사용한 if문
jumsu=55
res=''
res = '합격' if jumsu>=60 else '불합격'
print(res)
